from setuptools import setup, find_packages

setup(
    name="TuModeloDeCliente-CristianoPatricio",
    version="1.1",
    description="Paquete de distribución",
    author="Curso-Python-flex",
    author_email="patricioecristiano@gmail.com",
    py_modules=['main'],  
    packages=find_packages()
)
